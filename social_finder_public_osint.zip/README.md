# Social Finder — Public OSINT

Website lokal untuk mencari kemungkinan profil publik berdasarkan **username**.

## Jalankan

1. Install Python 3.10+.
2. Buka terminal di folder project.
3. Jalankan:

```bash
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

macOS/Linux:
```bash
source .venv/bin/activate
```

Lalu:

```bash
pip install -r requirements.txt
python app.py
```

Buka `http://127.0.0.1:5000`.

## Catatan

- Pemeriksaan hanya terhadap URL publik.
- HTTP 200 diberi label `possible`, bukan `confirmed`, karena beberapa platform menggunakan login/challenge page.
- Mode nomor HP hanya melakukan validasi dasar dan **tidak melakukan reverse lookup** ke akun pribadi.
- Untuk pencarian nama lengkap, gunakan mesin pencari/API resmi dan tampilkan hasil publik secara transparan; nama yang sama tidak membuktikan identitas yang sama.
